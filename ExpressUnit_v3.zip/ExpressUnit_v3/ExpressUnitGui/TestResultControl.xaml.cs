﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressUnit;

namespace ExpressUnitGui
{
    /// <summary>
    /// Interaction logic for TestResult.xaml
    /// </summary>
    public partial class TestResultControl : UserControl
    {
        public TestResultControl()
        {
            InitializeComponent();
            details.Visibility = Visibility.Collapsed;
        }

        public TestResult TestResult
        {
            get;
            set;
        }

        
        public void Initialize(TestResult result)
        {
            TestResult = result;
            resultSection.DataContext = result;
            if (result.Passed == true)
            {
                outerBorder.BorderBrush = Brushes.Green;
                HideErrorControls();
            }
            else
            {
                outerBorder.BorderBrush = Brushes.Red;
                lblDuration1.Visibility = lblDuration2.Visibility = Visibility.Collapsed;
            }
        }

        private void HideErrorControls()
        {
            lblError1.Visibility = lblError2.Visibility = Visibility.Collapsed;
            lblStackTrace1.Visibility = lblStackTrace2.Visibility = Visibility.Collapsed;
        }

        private void BtnExpand_Click(object sender, RoutedEventArgs e)
        {
            if (details.Visibility == Visibility.Visible)
            {
                details.Visibility = Visibility.Collapsed;
            }
            else
            {
                details.Visibility = Visibility.Visible;
            }
        }
    }
}
