﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Threading;
using System.Windows.Controls;
using ExpressUnit;

namespace ExpressUnitGui
{
    public class BaseWindow : System.Windows.Window
    {
        

        protected void SetTextBlockFromWorkerThread(TextBlock textBlock, string msg)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal,
                    new Action(
                        delegate()
                        {
                            textBlock.Text = msg;
                        }
                        ));
        }

        protected void SetTreeNodeColor(TestMethod node, string color)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal,
                 new Action(
                     delegate()
                     {
                         node.Color = color;
                     }
                     ));
        }
    }
}
