﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using ExpressUnit;

namespace ExpressUnitGui
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static bool RunAllTests
        {
            get;
            set;
        }

        public static bool ConsoleMode
        {
            get;
            set;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);


            if (e.Args.Length == 1)
            {
                RunAllTests = e.Args[0].ToLower() == "runtests";
                ConsoleMode = true;
            }
            else
            {
                AppSettingsReader appSettings = new AppSettingsReader();
                RunAllTests = (bool)appSettings.GetValue("runTestsOnStartup", typeof(bool));
                ConsoleMode = false;
            }

        }
    }
}
