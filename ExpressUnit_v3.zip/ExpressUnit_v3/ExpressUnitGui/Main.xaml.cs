﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ExpressUnit;
using ExpressUnitModel;
using System.ComponentModel;
using System.Windows.Threading;
using System.Xml.Linq;

namespace ExpressUnitGui
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : BaseWindow
    {
        private BackgroundWorker backgroundWorker;
        private int testsPassed = 0;
        private int testsFailed = 0;
        private TestManager testManager = new TestManager();
        public Main()
        {
            InitializeComponent();
            Initialize();
        }

        private void Initialize()
        {
            testTree.ItemsSource = testManager.GetTests(TestType.All);
            cmbTestType.SelectedIndex = 2;

            if (App.RunAllTests == true)
            {
                backgroundWorker = new BackgroundWorker();
                backgroundWorker.DoWork += new DoWorkEventHandler(backgroundWorker_RunAllTests);
                backgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker_RunAllTestsCompleted);
                backgroundWorker.RunWorkerAsync();
            }
        }

      

        private void RunAllTests()
        {
            ClearTestResult();
            foreach (TestFixture fixture in testTree.Items)
            {
                Run(fixture);
            }
        }

        private void TestType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = cmbTestType.SelectedValue as ComboBoxItem;
            testTree.ItemsSource = testManager.GetTests(item.Name);
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            ClearTestResult();

            backgroundWorker = new BackgroundWorker();
            backgroundWorker.DoWork += new DoWorkEventHandler(backgroundWorker_RunSelectedTests);
            backgroundWorker.RunWorkerAsync(testTree.SelectedValue as ITest);
        }

        void backgroundWorker_RunSelectedTests(object sender, DoWorkEventArgs e)
        {
            Run(e.Argument as ITest);
        }

        void backgroundWorker_RunAllTests(object sender, DoWorkEventArgs e)
        {
            RunAllTests();
        }

        void backgroundWorker_RunAllTestsCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            btnRunAllTests.IsEnabled = true;
        
            var q = from TestResultControl t in resultPanel.Children
                    select t.TestResult;

            XDocument doc = XmlManager.CreateTestReport(q.ToArray<TestResult>());
            doc.Save("report.xml", SaveOptions.DisableFormatting);

            if (App.ConsoleMode == true)
            {
                Application.Current.Shutdown();
            }
        }

        private void RunAllTest_Click(object sender, RoutedEventArgs e)
        {
            btnRunAllTests.IsEnabled = false;
            backgroundWorker = new BackgroundWorker();
            backgroundWorker.DoWork += new DoWorkEventHandler(backgroundWorker_RunAllTests);
            backgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker_RunAllTestsCompleted);
            backgroundWorker.RunWorkerAsync();
        }

        private void Run(ITest iTest)
        {
            DateTime start = DateTime.Now;
            SetTextBlockFromWorkerThread(txtLastTestRun, DateTime.Now.ToString());
           
            if (iTest.TestConstruct == TestConstruct.TestMethod)
            {
                Run(iTest as TestMethod);
            }
            else
            {
                TestFixture fixture = iTest as TestFixture;
                ExpandTreeNode(fixture);
                foreach (TestMethod method in fixture.Tests)
                {
                    Run(method);
                }
            }
            SetTextBlockFromWorkerThread(txtPassed,testsPassed.ToString());
            SetTextBlockFromWorkerThread(txtFailed,testsFailed.ToString());
            SetTextBlockFromWorkerThread(txtDuration,(DateTime.Now - start).ToString());
        }

        private void Run(TestMethod method)
        {
            SetTextBlockFromWorkerThread(txtCurrentTest, method.Name);

            TestResult res = testManager.RunTest(method);

            AddResultControl(res);
         
            if (res.Passed == true)
            {
                SetTreeNodeColor(method, "Green");
                testsPassed++;
                SetTextBlockFromWorkerThread(txtPassed,testsPassed.ToString());
            }
            else
            {
                SetTreeNodeColor(method, "Red");
                testsFailed++;
                SetTextBlockFromWorkerThread(txtFailed,testsFailed.ToString());
            }
        }

        private void ClearTestResult()
        {
            Dispatcher.Invoke(DispatcherPriority.Normal,
                    new Action(
                        delegate()
                        {
                            resultPanel.Children.Clear();
                            testsPassed = 0;
                            testsFailed = 0;
                        }
                        ));
        }

        private void ExpandTreeNode(TestFixture fixture)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal,
                    new Action(
                        delegate()
                        {
                            TreeViewItem treeItem = testTree.ItemContainerGenerator.ContainerFromItem(fixture) as TreeViewItem;
                            treeItem.IsExpanded = true;
                        }
                        ));

        }

        protected void AddResultControl(TestResult res)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal,
                    new Action(
                        delegate()
                        {
                            TestResultControl resultControl = new TestResultControl();
                            resultControl.Initialize(res);
                            resultPanel.Children.Add(resultControl);
                        }
                        ));
        }
    }
}
