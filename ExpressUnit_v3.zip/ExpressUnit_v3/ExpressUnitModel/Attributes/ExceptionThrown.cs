﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace ExpressUnitModel
{
    [AttributeUsage(AttributeTargets.Method)]
    public class ExceptionThrown : Attribute
    {
        public ExceptionThrown(Type type)
        {
            ExceptionType = type;
        }

        public Type ExceptionType
        {
            get;
            set;
        }

        private bool ExceptionIsExcepted(MemberInfo method,Exception ex)
        {
            object[] attribute = method.GetCustomAttributes(typeof(ExceptionThrown), true);
            foreach (ExceptionThrown exAtt in attribute)
            {
                if (exAtt.GetType() == ex.GetType())
                {
                    return true;
                }
            }

            return false;
        }
    }
}
