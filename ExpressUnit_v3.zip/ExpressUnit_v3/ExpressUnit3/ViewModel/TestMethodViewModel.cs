﻿/*
Copyright (C) 2009  Torgeir Helgevold

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnit;
using System.Windows.Media;
using System.Collections;
using System.Windows.Input;
using System.Windows.Forms;
using System.Windows.Controls;
using System.ComponentModel;
using System.Xml.Linq;
using System.Windows.Documents;

namespace ViewModel
{
    public delegate void AddResultControl(TestResult res);
    public delegate void ClearResultControl();
    public delegate void CloseApp();

    public class TestMethodViewModel : BaseViewModel
    {
        private BackgroundWorker backgroundWorker;
        private ICommand loadTestsCommand;
        private ICommand runTestsCommand;
        private ComboBoxItem selectedItem;
        private IList<TestFixture> tests;
        private IList<TestResult> testResults;
        private ITestManager testManager = new TestManager();
        private int testsPassed;
        private int testsFailed;
        private string currentTest;
        private AddResultControl addResultControl;
        private ClearResultControl clearResultControl;
        private string lastTestRun;
        private string totalRunTime;
        private bool playButtonIsEnabled;
        private bool generateReport;
       
        public TestMethodViewModel(AddResultControl addResultControl,ClearResultControl clearResultControl)
        {
            this.addResultControl = addResultControl;
            this.clearResultControl = clearResultControl;
            PlayButtonEnabled = true;

        }

        public CloseApp CloseApp
        {
            get;
            set;
        }

        public bool PlayButtonEnabled
        {
            get
            {
                return playButtonIsEnabled;
            }
            set
            {
                playButtonIsEnabled = true;
                OnPropertyChanged("PlayButtonEnabled");
            }
        }

        public bool GenerateReport
        {
            get
            {
                return generateReport;
            }
            set
            {
                generateReport = value;
            }
        }

        public ITestManager TestManager
        {
            get
            {
                return testManager;
            }
            set
            {
                testManager = value;
            }
        }

        public string TotalRunTime
        {
            get
            {
                return totalRunTime;
            }
            set
            {
                totalRunTime = value;
                OnPropertyChanged("TotalRunTime");
            }
        }

        public string LastTestRun
        {
            get
            {
                return lastTestRun;
            }
            set
            {
                lastTestRun = value;
                OnPropertyChanged("LastTestRun");
            }
        }

        public string CurrentTest
        {
            get
            {
                return currentTest;
            }
            set
            {
                currentTest = value;
            }
        }

        public int TestsPassed
        {
            get
            {
                return testsPassed;
            }
            set
            {
                testsPassed = value;
                OnPropertyChanged("TestsPassed");
            }
        }

        public int TestsFailed
        {
            get
            {
                return testsFailed;
            }
            set
            {
                testsFailed = value;
                OnPropertyChanged("TestsFailed");
            }
        }

        void backgroundWorker_RunAllTests(object sender, DoWorkEventArgs e)
        {
            RunAllTests();
        }

        #region Commands

        public ICommand RunTestsCommand
        {
            get
            {
                if (runTestsCommand == null)
                {
                    runTestsCommand = new RelayCommand(RunTests);
                }
                return runTestsCommand;
            }
        }

        public ICommand LoadTestsCommand
        {
            get
            {
                if (loadTestsCommand == null)
                {
                    loadTestsCommand = new RelayCommand(LoadTests);
                }

                return loadTestsCommand;
            }
        }

        #endregion

        public IList<TestResult> TestResults
        {
            get
            {
                return testResults;
            }
            set
            {
                testResults = value;
                OnPropertyChanged("TestResults");
            }
        }

        public ComboBoxItem SelectedItem
        {
            get
            {
                return selectedItem;
            }
            set
            {
                selectedItem = value;
                LoadTests();
                OnPropertyChanged("SelectedItem");
            }
        }

        public IList<TestFixture> Tests
        {
            get
            {
                return tests;
            }
            set
            {
                tests = value;
                OnPropertyChanged("Tests");
            }
        }

        private void ResetTreeNodeColor()
        {
            foreach (TestFixture f in Tests)
            {
                foreach (TestMethod m in f.Tests)
                {
                    m.Color = "Yellow";
                }
            }
        }

        public void SetSelectedTests(ITest iTest)
        {
            this.Tests = new List<TestFixture>();

            if (iTest.TestConstruct == TestConstruct.TestMethod)
            {
                TestFixture newFixture = new TestFixture();
                newFixture.Tests = new List<TestMethod>();
                newFixture.Tests.Add(iTest as TestMethod);
                this.Tests.Add(newFixture);
            }
            else
            {
                this.Tests.Add((TestFixture)iTest);
            }
        }

        public void LoadTests(string testType)
        {
            TestManager manager = new TestManager();
            Tests = manager.GetTests(testType);
        }

        private void RunTests()
        {
            if (PlayButtonEnabled == false)
            {
                return;
            }

            ResetTreeNodeColor();

            PlayButtonEnabled = false;

            backgroundWorker = new BackgroundWorker();
            backgroundWorker.DoWork += new DoWorkEventHandler(backgroundWorker_RunAllTests);
            backgroundWorker.RunWorkerAsync();
        }

        private void RunAllTests()
        {
            DateTime start = DateTime.Now;

            TestResults = new List<TestResult>();
            LastTestRun = DateTime.Now.ToString("hh:mm:ss");
            this.clearResultControl();
            TestsPassed = 0;
            TestsFailed = 0;
            foreach (TestFixture fixture in Tests)
            {
                RunTest(fixture);
            }

            TotalRunTime = (DateTime.Now - start).ToString();

            if (GenerateReport == true)
            {
                XDocument doc = XmlManager.CreateTestReport(this.TestResults);
                doc.Save("report.xml", SaveOptions.DisableFormatting);
                CloseApp();
            }


            PlayButtonEnabled = true;
        }

        private void RunTest(ITest iTest)
        {
            if (iTest.TestConstruct == TestConstruct.TestMethod)
            {
                TestFixture newFixture = new TestFixture();
                newFixture.Tests = new List<TestMethod>();
                newFixture.Tests.Add(iTest as TestMethod);
                Tests = new List<TestFixture>();
            }
            
            TestFixture fixture = iTest as TestFixture;
            foreach (TestMethod method in fixture.Tests)
            {
                Run(method);
            }
            
        }

        private void Run(TestMethod method)
        {
            CurrentTest = method.Name;

            TestResult res = TestManager.RunTest(method);
            
            if (res.Passed == true)
            {
                method.Color = "Green";
                TestsPassed++;
            }
            else
            {
                method.Color = "Red";
                TestsFailed++;
            }
            this.addResultControl(res);
            this.TestResults.Add(res);
        }


        private void LoadTests()
        {
            TestManager manager = new TestManager();
            Tests = manager.GetTests(SelectedItem.Name);
        }
       
    }
}
