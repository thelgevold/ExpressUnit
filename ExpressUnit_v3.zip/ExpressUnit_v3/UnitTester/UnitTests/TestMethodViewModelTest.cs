﻿/*
Copyright (C) 2009  Torgeir Helgevold

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using ViewModel;
using System.Windows.Controls;
using ExpressUnit;
using System.Windows.Threading;
using System.Threading;
using UnitTester.Mocks;

namespace UnitTester.UnitTests
{
    
    [TestClass]
    public class TestMethodViewModelTest
    {
        [UnitTest]
        public void SetSelectedTests_Will_Load_Selected_Test_To_Test_Collection_Test()
        {
            TestMethod m = new TestMethod();
            m.Name = "M1";
            
            TestMethodViewModel viewModel = new TestMethodViewModel(AddResultControl,ClearResultControl);

            viewModel.SetSelectedTests(m);

            Confirm.Equals(1, viewModel.Tests.Count);
            Confirm.Equals(1, viewModel.Tests[0].Tests.Count);
            Confirm.Equals("M1", viewModel.Tests[0].Tests[0].Name);

        }

        [UnitTest]
        public void SetSelectedTests_Will_Load_Selected_Fixture_To_Fixture_Collection_Test()
        {
            TestFixture f = new TestFixture();
            f.Name = "F1";
            TestMethod m = new TestMethod();
            m.Name = "M1";
            f.Tests = new List<TestMethod>();

            f.Tests.Add(m);

            TestMethodViewModel viewModel = new TestMethodViewModel(AddResultControl,ClearResultControl);

            viewModel.SetSelectedTests(f);

            Confirm.Equals(1, viewModel.Tests.Count);
            Confirm.Equals("F1",viewModel.Tests[0].Name);

            Confirm.Equals(1,viewModel.Tests[0].Tests.Count);
            Confirm.Equals("M1", viewModel.Tests[0].Tests[0].Name);
        }

        [UnitTest]
        public void Setting_SelectedItem_Will_Load_Tests()
        {
            Thread t;
            t = new Thread(TestBody);
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
        }

        private void TestBody()
        {
            TestMethodViewModel viewModel = new TestMethodViewModel(AddResultControl,ClearResultControl);

            viewModel.Tests = new List<TestFixture>();
            Confirm.Equals(0, viewModel.Tests.Count);

            ComboBoxItem item = new ComboBoxItem();
            item.Name = "UnitTests";
            viewModel.SelectedItem = item;

            Confirm.Different(0, viewModel.Tests.Count);

        }

        [UnitTest]
        public void RunTestCommand_Will_Execute_Passing_Test()
        {
            TestMethodViewModel viewModel = new TestMethodViewModel(AddResultControl, ClearResultControl);

            MockTestManager testManager = new MockTestManager();
            testManager.PassTests = true;

            viewModel.TestManager = testManager;

            TestFixture fixture = new TestFixture();

            TestMethod testMethod = new TestMethod();
            testMethod.Name = "test1";
            fixture.Tests = new List<TestMethod>();
            fixture.Tests.Add(testMethod);

            viewModel.Tests = new List<TestFixture>();
            viewModel.Tests.Add(fixture);

            viewModel.RunTestsCommand.Execute(null);

            Thread.Sleep(5000);

            Confirm.Equals(1, viewModel.TestsPassed);
            Confirm.Equals(0,viewModel.TestsFailed);

            Confirm.Equals("test1",viewModel.CurrentTest);
       
        }

        public void AddResultControl(TestResult res) { }

        public void ClearResultControl(){}

    }
}
