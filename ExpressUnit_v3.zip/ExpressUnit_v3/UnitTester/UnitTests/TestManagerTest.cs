﻿/*
Copyright (C) 2009  Torgeir Helgevold

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using ExpressUnit;
using System.Reflection;

namespace UnitTester.UnitTests
{
    [TestClass]
    public class TestManagerTest
    {
        [UnitTest]
        public void TestManager_RunTest_Will_Run_Passing_Test_Test()
        {
            TestManager manager = new TestManager();
            TestMethod method = new TestMethod();
            method.Name = "PassingStub";
            method.Type = typeof(TestManagerTest);
            method.MemberInfo = PassingStub();

            TestResult res = manager.RunTest(method);
            Confirm.Equals(true, res.Passed);
            Confirm.Equals("PassingStub (PASSED)", res.ResultText);
        }

        [UnitTest]
        public void TestManager_RunTest_Will_Run_Failing_Test_When_Unhandled_Exception_Is_Thrown_Test()
        {
            TestManager manager = new TestManager();
            TestMethod method = new TestMethod();
            method.Name = "FailingStubWithUnhandledException";
            method.Type = typeof(TestManagerTest);
           
            Type t = typeof(TestManagerTest);
            var q = from m in t.GetMembers()
                    where m.Name == "FailingStubWithUnhandledException"
                    select m;

            method.MemberInfo = q.Single<MemberInfo>();

            TestResult res = manager.RunTest(method);
            Confirm.Equals(false, res.Passed);
            Confirm.Equals("Argument Invalid", res.ResultText);
        }

        

        [UnitTest]
        public void TestManager_RunTest_Will_Run_Failing_Test_When_Confirm_Equals_Fails_Test()
        {
            TestManager manager = new TestManager();
            TestMethod method = new TestMethod();
            method.Name = "FailingStubWithFailingConfirmEquals";
            method.Type = typeof(TestManagerTest);

            Type t = typeof(TestManagerTest);
            var q = from m in t.GetMembers()
                    where m.Name == "FailingStubWithFailingConfirmEquals"
                    select m;

            method.MemberInfo = q.Single<MemberInfo>();

            TestResult res = manager.RunTest(method);
            Confirm.Equals("The expected value is: [1], but the actual value is: [2]", res.ResultText);
            Confirm.Equals(false, res.Passed);
        }

        [UnitTest]
        public void TestManager_RunTest_Will_Run_Failing_Test_When_Confirm_Different_Fails_Test()
        {
            TestManager manager = new TestManager();
            TestMethod method = new TestMethod();
            method.Name = "FailingStubWithFailingConfirmDifferent";
            method.Type = typeof(TestManagerTest);

            Type t = typeof(TestManagerTest);
            var q = from m in t.GetMembers()
                    where m.Name == "FailingStubWithFailingConfirmDifferent"
                    select m;

            method.MemberInfo = q.Single<MemberInfo>();

            TestResult res = manager.RunTest(method);
            Confirm.Equals("The the actual value should not be equal to Not Expected Value", res.ResultText);
            Confirm.Equals(false, res.Passed);
        }

        [UnitTest]
        public void TestManager_RunTest_Will_Run_Failing_Test_When_Confirm_IsGreater_Fails_Test()
        {
            TestManager manager = new TestManager();
            TestMethod method = new TestMethod();
            method.Name = "FailingStubWithFailingConfirmIsGreater";
            method.Type = typeof(TestManagerTest);

            Type t = typeof(TestManagerTest);
            var q = from m in t.GetMembers()
                    where m.Name == "FailingStubWithFailingConfirmIsGreater"
                    select m;

            method.MemberInfo = q.Single<MemberInfo>();

            TestResult res = manager.RunTest(method);
            Confirm.Equals("2.3 is not greater than 4.2", res.ResultText);
            Confirm.Equals(false, res.Passed);
        }

        public void FailingStubWithFailingConfirmIsGreater()
        {
            Confirm.IsGreater(2.3, 4.2);
        }

        public void FailingStubWithFailingConfirmDifferent()
        {
            Confirm.Different("Not Expected Value", "Not Expected Value");
        }
 
        public void FailingStubWithFailingConfirmEquals()
        {
            Confirm.Equals(1, 2);
        }
       
        public void FailingStubWithUnhandledException()
        {
            throw new Exception("Argument Invalid");            
        }

        public System.Reflection.MethodBase PassingStub()
        {
            return System.Reflection.MethodBase.GetCurrentMethod();
        }
    }
}
