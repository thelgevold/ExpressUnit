﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using ExpressUnit;

namespace UnitTester.Tests
{
    [TestClass]
    public class AttributeManagerTest
    {
        [UnitTest]
        [ExceptionThrown(typeof(DivideByZeroException))]
        public void ExceptionIsExcepted_Returns_True_For_Expected_Exception_Test()
        {
            Exception ex = new Exception("", new DivideByZeroException());
            Confirm.Equals(true,AttributeManager.ExceptionIsExcepted(System.Reflection.MethodBase.GetCurrentMethod(), ex));

            // must do this to satisfy DivideByZeroException check
            throw new DivideByZeroException();
        }
    }
}
