﻿/*
Copyright (C) 2009  Torgeir Helgevold

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using ExpressUnit;
using System.Collections;

namespace UnitTester.UnitTests
{
    [TestClass]
    public class MethodManagerTest
    {
        private MethodManager manager = new MethodManager();

        [UnitTest(TestScenario = "All tests methods for a type will be located")]
        [ExceptionThrown(typeof(ArgumentException))]
        public void MethodManager_GetTestsInTestClass_Will_Throw_Exception_Argument_Exception_If_Test_Type_Is_Undefined_Test()
        {
            manager.GetTestsInTestClass(typeof(MethodManagerTest), "Undefined");
        }

        [UnitTest(TestScenario = "All tests methods for a type will be located")]
        public void MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_And_One_Integration_Test_In_Current_Type_Test()
        {
            IList<TestMethod> tests = manager.GetTestsInTestClass(typeof(MethodManagerTest), TestType.All);

            Confirm.Equals(4, tests.Count);

            TestMethod method = tests[0];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_One_Integration_Test_In_Current_Type_Test");

            method = tests[1];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_And_One_Integration_Test_In_Current_Type_Test");
            Confirm.Equals(System.Reflection.MethodBase.GetCurrentMethod(), method.MemberInfo);

            method = tests[2];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_In_Current_Type_Test");

            method = tests[3];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Throw_Exception_Argument_Exception_If_Test_Type_Is_Undefined_Test");
            
        }

        [UnitTest(TestScenario = "All tests methods for a type will be located")]
        public void MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_In_Current_Type_Test()
        {
            IList<TestMethod> tests = manager.GetTestsInTestClass(typeof(MethodManagerTest), TestType.UnitTest);

            Confirm.Equals(3, tests.Count);

            TestMethod method = tests[0];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_And_One_Integration_Test_In_Current_Type_Test");

            method = tests[1];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_Three_Unit_Tests_In_Current_Type_Test");
            Confirm.Equals(System.Reflection.MethodBase.GetCurrentMethod(), method.MemberInfo);

            method = tests[2];
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Throw_Exception_Argument_Exception_If_Test_Type_Is_Undefined_Test");
        }

        [IntegrationTest(TestScenario = "All tests methods for a type will be located")]
        public void MethodManager_GetTestsInTestClass_Will_Find_One_Integration_Test_In_Current_Type_Test()
        {
            IList<TestMethod> tests = manager.GetTestsInTestClass(typeof(MethodManagerTest), TestType.IntegrationTest);

            Confirm.Equals(1, tests.Count);
            TestMethod method = tests[0];

            Confirm.Equals(System.Reflection.MethodBase.GetCurrentMethod(), method.MemberInfo);
            EnsureCorrectTestResult(method, "MethodManager_GetTestsInTestClass_Will_Find_One_Integration_Test_In_Current_Type_Test");
        }

        private void EnsureCorrectTestResult(TestMethod method,string testName)
        {
            Confirm.Equals(testName, method.Name);
            Confirm.Equals(typeof(MethodManagerTest), method.Type);
            Confirm.Equals("Yellow", method.Color);
        }
    }
}
