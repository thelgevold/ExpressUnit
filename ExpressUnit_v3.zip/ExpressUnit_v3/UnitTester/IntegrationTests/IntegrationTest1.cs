﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using System.Threading;

namespace UnitTester.IntegrationTests
{
    [TestClass]
    public class IntegrationTest1
    {
        [IntegrationTest]
        public void Test1() 
        {
            Thread.Sleep(5000);
        }

        [IntegrationTest]
        public void Test2() { }

        [IntegrationTest]
        public void Test3() { }
    }
}
