﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressUnit
{
    public interface ITest
    {
        TestConstruct TestConstruct { get; }
    }
}
