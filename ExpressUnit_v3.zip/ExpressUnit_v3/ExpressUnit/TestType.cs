﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressUnit
{
    public class TestType
    {
        public static string UnitTest = "UnitTests";
        public static string IntegrationTest = "IntegrationTests";
        public static string All = "AllTests";
    }
}
