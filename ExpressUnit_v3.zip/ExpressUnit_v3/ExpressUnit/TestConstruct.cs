﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressUnit
{
    public enum TestConstruct
    {
        TestMethod = 1,
        TestClass = 2
 
    }
}
