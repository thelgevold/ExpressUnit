﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace ExpressUnit
{
    public class TestFixture : ITest
    {

        public IList<TestMethod> Tests
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public TestConstruct TestConstruct
        {
            get { return TestConstruct.TestClass; }
        }
    }
}
