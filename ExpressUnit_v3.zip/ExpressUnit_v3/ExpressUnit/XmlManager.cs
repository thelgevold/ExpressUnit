﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Collections;
using System.IO;

namespace ExpressUnit
{
    public class XmlManager
    {

        /*
         *
         * <testsuite name="nosetests" tests="1" errors="1" failures="0" skip="0">
    <testcase classname="path_to_test_suite.TestSomething" 
              name="path_to_test_suite.TestSomething.test_it" time="0">
        <error type="error">
       
        </error>
    </testcase>
</testsuite>
         */

        public static XDocument CreateTestReport(TestResult[] testResults)
        {
            XDocument doc = new XDocument();

            var failures = from t in testResults where t.Passed == false select t;

            int failureCount = failures.ToArray<TestResult>().Length;

            XElement testSuite = new XElement("testsuite");

            testSuite.Add(new XAttribute("name", "main"));
            testSuite.Add(new XAttribute("tests", testResults.Length));
            testSuite.Add(new XAttribute("errors", failureCount));
            testSuite.Add(new XAttribute("failures", failureCount));
            testSuite.Add(new XAttribute("skip", 0));


            doc.Add(testSuite);

            foreach (TestResult res in testResults)
            {
                XElement test = new XElement("testcase");
                test.Add(new XAttribute("name", res.TestName));
                test.Add(new XAttribute("time", res.Duration));

                if (res.Passed == false)
                {
                    XElement error = new XElement("error");
                    error.Add(new XAttribute("type","error"));

                    test.Add(error);
                }
                
                testSuite.Add(test);
            }


            return doc;
        }
    }
}
