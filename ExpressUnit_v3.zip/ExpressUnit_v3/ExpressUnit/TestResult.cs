﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressUnit
{
    public class TestResult
    {
        private string testName;
        private Exception ex;
        private bool passed;
        public TestResult()
        {
            
        }

        public TimeSpan Duration
        {
            get;
            set;
        }

        public string TestName
        {
            get
            {
                return testName;
            }
            set
            {
                testName = value;
            }
        }

        public bool Passed
        {
            get
            {
                return passed;
            }
            set
            {
                passed = value;
            }
        }

        public string ResultText
        {
            get;
            set;
        }

        public string StackTrace
        {
            get
            {
                if (Exception != null)
                {
                    return Exception.StackTrace;
                }
                return string.Empty;
            }
        }

        public Exception Exception
        {
            get
            {
                return ex;
            }
            set
            {
                ex = value;
            }
        }


    }
}
