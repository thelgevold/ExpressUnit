﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Windows;

namespace ExpressUnit
{
    public class TestMethod :UIElement, ITest
    {
        public static readonly DependencyProperty ColorProperty;

        static TestMethod()
        {
            ColorProperty = DependencyProperty.Register("Color", typeof(string), typeof(TestMethod));
        }

        public string Color
        {
            get
            {
                return (string)GetValue(ColorProperty);
            }
            set
            {
                SetValue(ColorProperty, value);
            }
        }

        public string Name
        {
            get;
            set;
        }

        public Type Type
        {
            get;
            set;
        }

        public MemberInfo MemberInfo
        {
            get;
            set;
        }


        public TestConstruct TestConstruct
        {
            get { return TestConstruct.TestMethod; }
        }

    }
}
