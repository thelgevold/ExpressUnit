﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressUnit.ExpressUnitGui
{
    public class TestProgressBar : ProgressBar
    {
        public TestProgressBar()
        {
            this.Minimum = 0;
            this.Step = 1;
            this.Value = 0;
        }

        delegate void SetCurrentValue(int value);
        public void SetValue(int value)
        {
            if (this.InvokeRequired)
            {
                SetCurrentValue val = new SetCurrentValue(SetValue);
                this.Invoke(val, new object[] { value });
            }
            else
            {
                this.Value = value;
            }
        }

        delegate void SetMax(int value);
        public void SetMaxValue(int value)
        {
            if (this.InvokeRequired)
            {
                SetMax max = new SetMax(SetMaxValue);
                this.Invoke(max,new object[] { value });
            }
            else
            {
                this.Maximum = value;
            }
        }

        delegate void UpdateValue();
        public void IncrementProgessBar()
        {
            if (this.InvokeRequired)
            {
                UpdateValue updater = new UpdateValue(IncrementProgessBar);
                this.Invoke(updater);
            }
            else
            {
                this.Value++;
            }
        }
    }
}
