﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace UnitTester.Helpers
{
    public class SameCollection : List<string>
    {
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            List<string> otherCol = obj as List<string>;

            for(int i = 0; i < this.Count; i++)
            {
                if (this[i].Equals(otherCol[i]) == false)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
