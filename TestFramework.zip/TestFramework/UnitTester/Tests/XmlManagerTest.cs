﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;
using ExpressUnit.Saml;

namespace UnitTester.Tests
{
    [TestClass]
    public class XmlManagerTest
    {
        [Ignore]
        [UnitTest]
        [ExceptionThrown(typeof(ArgumentException))]
        public void XmlManager_XmlConfirmsToSaml20Schema_Will_Return_False_If_Xml_Does_Not_Comply_Test()
        {
            XmlManager xmlManager = new XmlManager();
            xmlManager.XmlConfirmsToSaml20Schema("<saml:Assertion xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion\">Test</saml:Assertion>");
        }

        [Ignore]
        [UnitTest]
        public void XmlManager_XmlConfirmsToSaml20Schema_Will_Return_True_If_Xml_Does_Comply_Test()
        {
            XmlManager xmlManager = new XmlManager();
            bool ok = xmlManager.XmlConfirmsToSaml20Schema(UnitTester.Properties.Resources.ValidSaml20Response);
            Confirm.Equals(true, ok);
        }
    }
}
