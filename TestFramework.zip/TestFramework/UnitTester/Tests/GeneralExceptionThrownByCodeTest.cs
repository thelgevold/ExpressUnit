﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;

namespace UnitTester.Tests
{
    [TestClass]
    public class GeneralExceptionThrownByCodeTest
    {
        [UnitTest]
        public void MethodWillThrowSystemException()
        {
            Confirm.Equals(true, ThrowSystemException());
        }

        [UnitTest]
        public void MethodWillThrowArgumentExceptionInsideSystemException()
        {
            Confirm.Equals(true, ThrowSystemExceptionWithArgumentExceptionAsInner());
        }

        private bool ThrowSystemExceptionWithArgumentExceptionAsInner()
        {
            ArgumentException inner = new ArgumentException("ArgumentException is inner, disregard failing test");  
            throw new Exception("This method throws System.Exception, disregard failing test", inner);

        }

        private bool ThrowSystemException()
        {
            throw new Exception("This method throws System.Exception, disregard failing test");
           
        }
    }
}
