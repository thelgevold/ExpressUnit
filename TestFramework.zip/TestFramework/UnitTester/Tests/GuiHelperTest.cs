﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnit;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;
using ExpressUnitModel;
using ExpressUnit.ExpressUnitGui;


namespace ExpressUnitTests
{
    [TestClass]
    public class GuiHelperTest : GuiHelper
    {
        [UnitTest]
        public void GetTestRunStatisticsWhen0OutOf0TestsArePassingTest()
        {
            List<TestResult> res = new List<TestResult>();
            
            GuiHelper helper = new GuiHelper();
            Statistics statistics = helper.GetStatistics(res);

            Confirm.Equals(0, statistics.PassedTests);
            Confirm.Equals(0, statistics.FailedTests);
        }

        [UnitTest]
        public void GetTestRunStatisticsWhen0OutOf4TestsArePassingTest()
        {
            List<TestResult> res = new List<TestResult>();
            TestResult r = new TestResult();
            r.Passed = false;
            res.Add(r);

            r = new TestResult();
            r.Passed = false;
            res.Add(r);

            r = new TestResult();
            r.Passed = false;
            res.Add(r);

            r = new TestResult();
            r.Passed = false;
            res.Add(r);

            GuiHelper helper = new GuiHelper();
            Statistics statistics = helper.GetStatistics(res);

            Confirm.Equals(0, statistics.PassedTests);
            Confirm.Equals(4, statistics.FailedTests);

        }

        [UnitTest]
        public void GetTestRunStatisticsWhen3OutOf4TestsArePassingTest()
        {
            List<TestResult> res = new List<TestResult>();
            TestResult r = new TestResult();
            r.Passed = true;
            res.Add(r);

            r = new TestResult();
            r.Passed = true;
            res.Add(r);

            r = new TestResult();
            r.Passed = true;
            res.Add(r);

            r = new TestResult();
            r.Passed = false;
            res.Add(r);

            GuiHelper helper = new GuiHelper();
            Statistics statistics = helper.GetStatistics(res);

            Confirm.Equals(3, statistics.PassedTests);
            Confirm.Equals(1, statistics.FailedTests);


        }

        [UnitTest]
        public void GetNodeCount_Will_Find_0_Nodes_Test()
        {
            TreeNode grandParent = new TreeNode();

            TreeNode parent = new TreeNode();

            grandParent.Nodes.Add(parent);

            TreeNode child = new TreeNode();
            parent.Nodes.Add(child);

            child = new TreeNode();
            parent.Nodes.Add(child);

            child = new TreeNode();
            parent.Nodes.Add(child);

            GuiHelper helper = new GuiHelper();

            int count = helper.GetNodeCount(parent);
            Confirm.Equals(0, count);
        }

        [UnitTest]
        public void GetNodeCount_Will_Find_3_Nodes_Test()
        {
            TreeNode grandParent = new TreeNode();

            TreeNode parent = new TreeNode();

            grandParent.Nodes.Add(parent);

            TreeNode child = new TreeNode();
            child.Tag = System.Reflection.MethodInfo.GetCurrentMethod();
            parent.Nodes.Add(child);

            child = new TreeNode();
            child.Tag = System.Reflection.MethodInfo.GetCurrentMethod();
            parent.Nodes.Add(child);

            child = new TreeNode();
            child.Tag = System.Reflection.MethodInfo.GetCurrentMethod();
            parent.Nodes.Add(child);

            GuiHelper helper = new GuiHelper();

            int count = helper.GetNodeCount(parent);
            Confirm.Equals(3, count);
        }

        [UnitTest]
        public void RunTestsTest()
        {
            GuiHelper helper = new GuiHelperTest();
            TestPanel panel = new TestPanel();
            TreeNode treeNode = new TreeNode();
            TestProgressBar progressBar = new TestProgressBar();

            helper.RunTests(treeNode, panel, progressBar);

            Confirm.Equals(Color.Green, panel.Controls[0].ForeColor);
            Confirm.Equals(Color.Red, panel.Controls[1].ForeColor);
        }

        protected override List<TestResult> GetTestResults(TreeNode node, TestProgressBar progressBar)
        {
            List<TestResult> res = new List<TestResult>();

            TestResult r1 = new TestResult();
            r1.Passed = true;
            res.Add(r1);

            r1 = new TestResult();
            r1.Passed = false;
            r1.Exception = new Exception("Failed");
            res.Add(r1);

            return res;
        }

        [UnitTest]
        public void PopulateTestTreeTest()
        {
            TreeView tree = new TreeView();
            tree.Nodes.Add("");
            GuiHelper helper = new GuiHelperTest();
            helper.PopulateTestTree(tree.Nodes[0]);

            Confirm.Equals(3, tree.Nodes[0].Nodes.Count);
            Confirm.Equals(tree.Nodes[0].Nodes[0].Text, "GuiHelperTest");
            Confirm.Equals(tree.Nodes[0].Nodes[0].Tag, typeof(ExpressUnitTests.GuiHelperTest));
        }

        [UnitTest]
        public void PopulateTestNodeTest()
        {
            GuiHelper helper = new GuiHelperTest();
            TreeNode node = new TreeNode();
            node.Tag = typeof(GuiHelperTest);
            helper.PopulateTestNode(node);

            Confirm.Equals(1, node.Nodes.Count);
            Confirm.Equals("PopulateTestNodeTest", node.Nodes[0].Text);
        }

        protected override MemberInfo[] GetTestMethods(Type t)
        {
            MemberInfo member = typeof(GuiHelperTest).GetMember("PopulateTestNodeTest")[0];
           
            MemberInfo[] array = new MemberInfo[1];
            array[0] = member;

            return array;
        }

        protected override Type[] GetTestTypes()
        {
            Type[] type = new Type[3];
            type[0] = typeof(GuiHelperTest);
            type[1] = typeof(GuiHelperTest);
            type[2] = typeof(GuiHelperTest);

            return type;
        }
    }
}
