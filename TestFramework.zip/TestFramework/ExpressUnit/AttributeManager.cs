﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using ExpressUnitModel;

namespace ExpressUnit
{
    public class AttributeManager
    {
        public static bool ExceptionIsExcepted(MemberInfo method, Exception ex)
        {
            object[] attribute = method.GetCustomAttributes(typeof(ExceptionThrown), true);
            foreach (ExceptionThrown exAtt in attribute)
            {
                if (ex.InnerException != null)
                {
                    if (exAtt.ExceptionType == ex.InnerException.GetType())
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
