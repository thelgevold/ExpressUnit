﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Collections;
using System.IO;
using ExpressUnitModel;
using System.Windows.Forms;
using ExpressUnit.ExpressUnitGui;

namespace ExpressUnit
{
    public class UnitTestManager
    {
        private TestProgressBar progressBar;
        public UnitTestManager():this(new TestProgressBar())  
        {
           
        }

        public UnitTestManager(TestProgressBar progressBar)
        {
            this.progressBar = progressBar;
        }

        public void ExecuteAllUnitTests(DisplayTestResults displayTestResults)
        {
            displayTestResults(RunTests());
        }

        public List<TestResult> RunTests()
        {
            List<TestResult> results = new List<TestResult>();
            Type[] types = GetUnitTestTypes();

            foreach (Type t in types)
            {
                results.AddRange(RunTests(t));
            }

            return results;
        }

        public TestResult RunTest(Type type,MemberInfo m)
        {
            TestResult result = new TestResult();
            try
            {
                result.TestName = m.Name;
                type.InvokeMember(m.Name, BindingFlags.InvokeMethod, null, Activator.CreateInstance(type), null);
                result = EnsureCorrectTestResult(m);
                this.progressBar.IncrementProgessBar();
            }
            catch (System.Exception ex)
            {
                result = HandleFailedTest(m, ex);
            }
           
           
            return result;
        }

        public List<TestResult> RunTests(Type t)
        {
            List<TestResult> results = new List<TestResult>();
            
            foreach (MemberInfo m in GetUnitTests(t))
            {
                TestResult result = new TestResult();
                result.TestName = m.Name;
                try
                {
                    t.InvokeMember(m.Name, BindingFlags.InvokeMethod, null, Activator.CreateInstance(t), null);
                    result = EnsureCorrectTestResult(m);
                    this.progressBar.IncrementProgessBar();
                }
                catch (System.Exception ex)
                {
                    result = HandleFailedTest(m, ex);
                }
                
                results.Add(result);
            }

            return results;
            
        }

        private TestResult HandleFailedTest(MemberInfo m, Exception ex)
        {
            TestResult result = new TestResult();
            if (AttributeManager.ExceptionIsExcepted(m, ex))
            {
                result.Passed = true;
                result.ResultText = GetTestPassedMessage(m.Name);
                this.progressBar.IncrementProgessBar();
                return result;
            }

            if (ex.InnerException != null)
            {
                result.Passed = false;

                if (ex.InnerException is UnitTestFailedException)
                {
                    result.ResultText = GetTestFailedMessage(m.Name, ex.InnerException.Message);
                }
                else
                {
                    result.ResultText = ex.InnerException.Message;
                }
            }
            else
            {
                result.ResultText = GetTestFailedMessage(m.Name, ex.Message);
            }
            this.progressBar.IncrementProgessBar();
            return result;
        }

        public MemberInfo[] GetUnitTests(Type t)
        {
            var q = from m in t.GetMembers()
                    where Attribute.IsDefined(m, typeof(UnitTest)) == true && Attribute.IsDefined(m, typeof(Ignore)) == false
                    select m;

            return q.ToArray<MemberInfo>();
        }
       
        public Type[] GetUnitTestTypes()
        {
            List<Type> allTypes = new List<Type>();

            Assembly currentAssembly = Assembly.GetEntryAssembly();
            Type[] types = currentAssembly.GetTypes();

            var q1 = from t in types
                    where Attribute.IsDefined(t, typeof(TestClass)) == true
                    select t;

            allTypes.AddRange(q1.ToArray());

            string[] dlls = Directory.GetFiles(Directory.GetCurrentDirectory(), "*.dll");

            foreach(string name in dlls)
            {
                currentAssembly = Assembly.LoadFile(name);
                types = currentAssembly.GetTypes(); 

                var q2 = from t in types
                        where Attribute.IsDefined(t, typeof(TestClass)) == true
                        select t;

                allTypes.AddRange(q2.ToArray());
            }
            return allTypes.ToArray<Type>();

        }

        private string GetTestFailedMessage(string testName, string error)
        {
            return string.Format("{0} {1} {2}", testName, "(FAILED)", error); ;
        }

        private string GetTestPassedMessage(string testName)
        {
            return string.Format("{0} {1}", testName, "(PASSED)"); 
        }

        private TestResult EnsureCorrectTestResult(MemberInfo method)
        {
            TestResult result = new TestResult();

            object[] attribute = method.GetCustomAttributes(typeof(ExceptionThrown), true);

            if (attribute.Length > 0)
            {
                ExceptionThrown expectedException = attribute[0] as ExceptionThrown;
                result.Passed = false;
                result.ResultText = GetTestFailedMessage(method.Name,string.Format("Exception of type {0} was expected", expectedException.ExceptionType));
                return result;
            }

            result.Passed = true;
            result.ResultText = GetTestPassedMessage(method.Name);
            return result;
        }

        
    }
}
