﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.IO;

namespace ExpressUnit.Saml
{
    public class XmlManager
    {
        public bool XmlConfirmsToSaml20Schema(string xml)
        {
            XmlReaderSettings dtdSettings = new XmlReaderSettings();
            dtdSettings.ProhibitDtd = false;

            XmlReaderSettings settings = new XmlReaderSettings();

            settings.ValidationType = ValidationType.Schema;

            settings.ValidationType = ValidationType.Schema;
            settings.Schemas.ValidationEventHandler += delegate(object
            sender, ValidationEventArgs vargs)
            {
                throw new ArgumentException(vargs.Message);
            };

            settings.Schemas.Add(null,
            XmlReader.Create(@"http://docs.oasis-open.org/security/saml/v2.0/saml-schema-protocol-2.0.xsd", dtdSettings));
            settings.ValidationEventHandler += delegate(object sender,
            ValidationEventArgs vargs)
            {
                throw new ArgumentException(vargs.Message);
            };

            
            StringReader stringReader = new StringReader(xml);

            using (XmlReader reader = XmlReader.Create(stringReader, settings))
            {
                while (reader.Read()) 
                {
                }
            }

            return true;
        }

        protected void ValidationEventHandler1(object sender, ValidationEventArgs vargs)
        {
            throw new ArgumentException(vargs.Message);
        }
        protected void ValidationEventHandler2(object sender, ValidationEventArgs vargs)
        {
            throw new ArgumentException(vargs.Message);
        }
    }
}
