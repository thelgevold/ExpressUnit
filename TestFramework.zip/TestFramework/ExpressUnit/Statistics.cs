﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressUnit
{
    public class Statistics
    {
        public int FailedTests
        {
            get;
            set;
        }

        public int PassedTests
        {
            get;
            set;
        }

    }
}
