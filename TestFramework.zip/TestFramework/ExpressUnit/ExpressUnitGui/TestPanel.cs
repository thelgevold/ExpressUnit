﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressUnit.ExpressUnitGui
{
    public class TestPanel : Panel
    {
        delegate void ClearAllControls();
        public void ClearControls()
        {
            if (this.InvokeRequired)
            {
                ClearAllControls c = new ClearAllControls(ClearControls);
                this.Invoke(c);
            }
            else
            {
                this.Controls.Clear();
            }
        }

        delegate void AddNewControl(Control control);
        public void AddControl(Control control)
        {
            if (this.InvokeRequired)
            {
                AddNewControl c = new AddNewControl(AddControl);
                this.Invoke(c, new object[] { control });
            }
            else
            {
                this.Controls.Add(control);
            }
        }
    }
}
