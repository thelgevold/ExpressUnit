﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;
using ExpressUnitModel;
using ExpressUnit.ExpressUnitGui;

namespace ExpressUnit
{
    public class GuiHelper
    {
        private int nodeCount = 0;
        public Statistics GetStatistics(IList<TestResult> res)
        {
            if (res == null)
            {
                return null;
            }

            Statistics statistics = new Statistics();

            var q = from r in res where r.Passed == true select r;

            statistics.PassedTests = q.ToList<TestResult>().Count;
            statistics.FailedTests = res.Count - statistics.PassedTests;

            return statistics;
        }

        public int GetNodeCount(TreeNode treeNode)
        {
            nodeCount = 0;
            MemberInfo tag = treeNode.Tag as MemberInfo;
            if (tag != null && tag.MemberType == MemberTypes.Method)
            {
                nodeCount++;
            }
            foreach (TreeNode node in treeNode.Nodes)
            {
                VisitNodes(node);
            }
            return nodeCount;
        }

        private void VisitNodes(TreeNode node)
        {
            MemberInfo tag = node.Tag as MemberInfo;
            if (tag != null && tag.MemberType == MemberTypes.Method)
            {
                nodeCount++;
            }

            foreach (TreeNode child in node.Nodes)
            {
                VisitNodes(child);
            }
        }

        public int PopulateTestTree(TreeNode treeNode)
        {
            int nodeCount = 0;
            Type[] types = GetTestTypes();
            foreach (Type t in types)
            {
                TreeNode node = new TreeNode();
                node.Tag = t;
                node.Text = t.Name;
                treeNode.Nodes.Add(node);
                nodeCount += PopulateTestNode(node);
            }

            return nodeCount;
        }

        public int PopulateTestNode(TreeNode treeNode)
        {
            int nodeCount = 0;
           
            treeNode.Nodes.Clear();
            MemberInfo[] members = GetTestMethods(treeNode.Tag as Type);
            foreach (MemberInfo m in members)
            {
                TreeNode node = new TreeNode();
                node.Tag = m;
                node.Text = m.Name;
                treeNode.Nodes.Add(node);
                nodeCount++;
            }

            return nodeCount;
        }

        public List<TestResult> RunTests(TreeNode node, TestPanel resultsPanel, TestProgressBar progressBar)
        {
            List<TestResult> results = new List<TestResult>();
            resultsPanel.ClearControls();
            int x = 20;
            int y = 0;

          
            List<TestResult> testResults = GetTestResults(node,progressBar);
            resultsPanel.VerticalScroll.Enabled = true;
            resultsPanel.HorizontalScroll.Enabled = false;
            foreach (TestResult res in testResults)
            {
                ToolTip tip = new ToolTip();
                Label lbl = new Label();
                lbl.AutoSize = true;
                lbl.Font = new Font("Arial", 12, FontStyle.Bold | FontStyle.Underline);
                lbl.Width = 800;
                lbl.Location = new Point(x, y);
                lbl.Text = res.ResultText;

                tip.SetToolTip(lbl, lbl.Text);

                if (res.Passed == false)
                {
                    lbl.ForeColor = Color.Red;
                }
                else
                {
                    lbl.ForeColor = Color.Green;
                }

                results.Add(res);
                resultsPanel.AddControl(lbl);
                y += lbl.Height + 10;
            }

            return results;
        }

        protected virtual List<TestResult> GetTestResults(TreeNode node, TestProgressBar progressBar)
        {
            UnitTestManager manager = new UnitTestManager(progressBar);
            List<TestResult> results = new List<TestResult>();
            
            // top node
            if (node.Parent == null)
            {
                results = manager.RunTests();
            }
            // test class
            else if (node.Parent.Parent == null)
            {
                results = manager.RunTests(node.Tag as Type);
            }
            
            // test method
            else
            {
                results.Add(manager.RunTest(node.Parent.Tag as Type,node.Tag as MemberInfo));
            }

            var sortedList = from r in results orderby r.ResultText ascending select r; 

            return sortedList.ToList<TestResult>();
        }

        protected virtual MemberInfo[] GetTestMethods(Type t)
        {
            UnitTestManager manager = new UnitTestManager();
            return manager.GetUnitTests(t);
        }

        protected virtual Type[] GetTestTypes()
        {
            UnitTestManager manager = new UnitTestManager();
            return manager.GetUnitTestTypes();
        }

    }
}
