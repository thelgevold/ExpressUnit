﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressUnit.ExpressUnitGui
{
    public class TestTreeView : TreeView
    {
        delegate TreeNode GetNodeNode();
        public TreeNode GetSelectedNode()
        {
            if (this.InvokeRequired)
            {
                GetNodeNode node = new GetNodeNode(GetSelectedNode);
                return this.Invoke(node) as TreeNode;
            }
            else
            {
                return this.SelectedNode;
            }
        }
    }
}
