﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using ExpressUnitModel;
using System.Collections;

namespace ExpressUnitModel
{
    public partial class Confirm
    {
        

        /// <summary>
        /// Compares the two values.  ComparerException is thrown if comp1 isn't greater than comp2
        /// </summary>
        /// <param name="comp1"></param>
        /// <param name="comp2"></param>
        /// <returns></returns>
        public static bool IsGreater(long comp1, long comp2)
        {
            bool val = comp1 > comp2;

            if (val == false)
            {
                throw new ComparerException();
            }
           
            return true;
        }

        /// <summary>
        /// Compares the two values.  ComparerException is thrown if comp1 isn't greater than comp2
        /// </summary>
        /// <param name="comp1"></param>
        /// <param name="comp2"></param>
        /// <returns></returns>
        public static bool IsGreater(double comp1, double comp2)
        {
            bool val = comp1 > comp2;

            if (val == false)
            {
                throw new ComparerException();
            }

            return true;
        }

        public static bool SameCollections(IEnumerable comp1, IEnumerable comp2)
        {
            if (comp1 == null && comp2 == null)
            {
                return true;
            }
            else if (comp1 == null)
            {
                return false;
            }
            else if (comp2 == null)
            {
                return false;
            }

            IList list1 = new List<object>();
            IList list2 = new List<object>();

            IEnumerator e1 = comp1.GetEnumerator();

            while (e1.MoveNext())
            {
                list1.Add(e1.Current);
            }

            IEnumerator e2 = comp2.GetEnumerator();

            while (e2.MoveNext())
            {
                list2.Add(e2.Current);
            }

            if (CompareCollections(list1, list2) == false)
            {
                throw new EqualityException(comp1, comp2);
            }

            return true;
        }

        
        private static bool CompareCollections(IList col1, IList col2)
        {
            if (col1.Count != col2.Count)
            {
                return false;
            }

            for (int i = 0; i < col1.Count; i++)
            {
                if (col1[i].Equals(col2[i]) == false)
                {
                    return false;
                }
            }
            
            return true;
        }

        /// <summary>
        /// Equals does its comparison based on object.Equals().  If both objects are null, they are 
        /// considered to be equal.
        /// </summary>
        /// <param name="expected"></param>
        /// <param name="actual"></param>
        /// <returns></returns>
        public new static bool Equals(object expected, object actual)
        {
            if (expected == null && actual == null)
            {
                return true;
            }
            else if (expected == null)
            {
                throw new EqualityException(expected, actual);
            }
            else if (actual == null)
            {
                throw new EqualityException(expected, actual);
            }
            else
            {
                if (expected.Equals(actual))
                {
                    return true;
                }
            }

            throw new EqualityException(expected, actual);
        }

        public static bool Different(object notExpected,object actual)
        {
            if (notExpected == null && actual == null)
            {
                throw new UnequalException(notExpected, actual);
            }
            else if (notExpected == null)
            {
                return true;
            }
            else if (actual == null)
            {
                return true;
            }
            else
            {
                if (notExpected.Equals(actual) == false)
                {
                    return true;
                }
            }

            throw new UnequalException(notExpected, actual);
        }

        
        public static bool ExceptionThrown(Type expectedExceptionType,TargetMethod target)
        {
            try
            {
                target();
            }
            catch (Exception ex)
            {
                if (ex.GetType() == expectedExceptionType)
                {
                    return true;
                }
                throw new ExceptionNotThrownException(expectedExceptionType,ex);
            }

            throw new ExceptionNotThrownException(expectedExceptionType, null);
        }

    }
}
