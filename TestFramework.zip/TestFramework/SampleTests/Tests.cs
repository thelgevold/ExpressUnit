﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;

namespace SampleTests
{
    [TestClass]
    public class Tests
    {
        [UnitTest]
        public void Test1()
        {
        }
    }
}
