﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ExpressUnit;
using System.Threading;
using ExpressUnit.ExpressUnitGui;
using ExpressUnitModel;

namespace ExpressUnitGui
{
    public partial class UnitTesting : UserControl
    {
        public UnitTesting()
        {
            InitializeComponent();
           
        }

        private bool testsInProgress = false;
        Thread thread;
        private GuiHelper helper = new GuiHelper();
        private ContextMenuStrip contextMenu;
      

        public void Init()
        {
            if (testClasses.Nodes.Count > 0)
            {
                return;
            }

            contextMenu = new ContextMenuStrip();
            contextMenu.Items.Add("RUN");
            contextMenu.ItemClicked += new ToolStripItemClickedEventHandler(ContextMenu_ItemClicked);

            TreeNode top = new TreeNode();
            testClasses.Nodes.Add(top);
            int count = helper.PopulateTestTree(testClasses.Nodes[0]);
            testClasses.Nodes[0].Text = string.Format("All tests ({0})", count);
        }

        protected void ContextMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (testClasses.SelectedNode == null)
            {
                return;
            }

            int count = helper.GetNodeCount(testClasses.SelectedNode);
            thread = new Thread(new ParameterizedThreadStart(RunTests));
            thread.Start(count);
        }

        delegate TestProgressBar GetProgressBar();
        public TestProgressBar GetTestProgressBar()
        {
            if (this.progressBar.InvokeRequired)
            {
                GetProgressBar getBar = new GetProgressBar(GetTestProgressBar);
                return this.progressBar.Invoke(getBar) as TestProgressBar;
            }
            else
            {
                return this.progressBar;
            }
        }

        delegate TestPanel GetTestPanel();
        public TestPanel GetTestResultPanel()
        {
            if (this.resultPanel.InvokeRequired)
            {
                GetTestPanel getBar = new GetTestPanel(GetTestResultPanel);
                return this.resultPanel.Invoke(getBar) as TestPanel;
            }
            else
            {
                return this.resultPanel;
            }
        }

        delegate TreeView GetTreeView();
        public TestTreeView GetTestClassTree()
        {
            if (this.testClasses.InvokeRequired)
            {
                GetTreeView getTreeView = new GetTreeView(GetTestClassTree);
                return this.testClasses.Invoke(getTreeView) as TestTreeView;
            }
            else
            {
                return this.testClasses;
            }
        }

        delegate void SetStatisticsLabel(string text);
        public void SetStatistics(string text)
        {
            if (this.lblStatistics.InvokeRequired)
            {
                SetStatisticsLabel s = new SetStatisticsLabel(SetStatistics);
                this.testStatistics.Invoke(s, new object[] { text });
            }
            else
            {
                this.testStatistics.Text = text;
            }
        }

        private void RunTests(object nodeCount)
        {
            testsInProgress = true;
            GetTestProgressBar().SetValue(0);
            GetTestProgressBar().SetMaxValue((int)nodeCount);
            List<TestResult> res = helper.RunTests(GetTestClassTree().GetSelectedNode(), GetTestResultPanel(), progressBar);
            Statistics statistics = helper.GetStatistics(res);
            
            SetStatistics(string.Format("{0} Out of {1} tests passed", statistics.PassedTests, statistics.PassedTests + statistics.FailedTests));
            testsInProgress = false;
            thread.Abort();
           
        }

        private void TestClasses_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (testsInProgress == true)
            {
                return;
            }
            if (e.Button == MouseButtons.Right)
            {
                contextMenu.Show(testClasses, e.Location);
            }
        }

       
        private void mainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (thread != null)
            {
                thread.Abort();
            }
        }

        private void resultPanel_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
