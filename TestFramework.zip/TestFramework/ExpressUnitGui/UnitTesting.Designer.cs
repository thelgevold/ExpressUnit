﻿namespace ExpressUnitGui
{
    partial class UnitTesting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblStatistics = new System.Windows.Forms.Label();
            this.testStatistics = new System.Windows.Forms.Label();
            this.progressBar = new ExpressUnit.ExpressUnitGui.TestProgressBar();
            this.testClasses = new ExpressUnit.ExpressUnitGui.TestTreeView();
            this.resultPanel = new ExpressUnit.ExpressUnitGui.TestPanel();
            this.SuspendLayout();
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // lblStatistics
            // 
            this.lblStatistics.AutoSize = true;
            this.lblStatistics.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatistics.Location = new System.Drawing.Point(258, -96);
            this.lblStatistics.Name = "lblStatistics";
            this.lblStatistics.Size = new System.Drawing.Size(18, 13);
            this.lblStatistics.TabIndex = 9;
            this.lblStatistics.Text = "tg";
            // 
            // testStatistics
            // 
            this.testStatistics.AutoSize = true;
            this.testStatistics.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.testStatistics.ForeColor = System.Drawing.Color.Green;
            this.testStatistics.Location = new System.Drawing.Point(12, 12);
            this.testStatistics.Name = "testStatistics";
            this.testStatistics.Size = new System.Drawing.Size(0, 19);
            this.testStatistics.TabIndex = 14;
            // 
            // progressBar
            // 
            this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar.Location = new System.Drawing.Point(0, 475);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(775, 28);
            this.progressBar.Step = 1;
            this.progressBar.TabIndex = 13;
            // 
            // testClasses
            // 
            this.testClasses.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.testClasses.Location = new System.Drawing.Point(0, 37);
            this.testClasses.Name = "testClasses";
            this.testClasses.Size = new System.Drawing.Size(258, 439);
            this.testClasses.TabIndex = 11;
            this.testClasses.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TestClasses_NodeMouseClick);
            // 
            // resultPanel
            // 
            this.resultPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.resultPanel.AutoScroll = true;
            this.resultPanel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.resultPanel.Location = new System.Drawing.Point(256, 37);
            this.resultPanel.Name = "resultPanel";
            this.resultPanel.Size = new System.Drawing.Size(519, 439);
            this.resultPanel.TabIndex = 12;
            this.resultPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.resultPanel_Paint);
            // 
            // UnitTesting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.testStatistics);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.testClasses);
            this.Controls.Add(this.resultPanel);
            this.Controls.Add(this.lblStatistics);
            this.Name = "UnitTesting";
            this.Size = new System.Drawing.Size(778, 506);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private ExpressUnit.ExpressUnitGui.TestTreeView testClasses;
        private System.Windows.Forms.Label lblStatistics;
        private ExpressUnit.ExpressUnitGui.TestPanel resultPanel;
        private ExpressUnit.ExpressUnitGui.TestProgressBar progressBar;
        private System.Windows.Forms.Label testStatistics;
    }
}
