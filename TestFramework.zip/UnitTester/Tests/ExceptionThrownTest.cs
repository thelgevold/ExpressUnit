﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ExpressUnitModel;

namespace UnitTester
{
    [TestClass]
    public class ExceptionThrownTest
    {
        [UnitTest]
        [ExceptionThrown(typeof(DivideByZeroException))]
        public void Divide_By_Zero_Exception_Is_Thrown_Test()
        {
            int a = 0;
            int b = 4;

            int c = b / a;
        }

        /// <summary>
        /// This test is supposed to fail to test the "expected exception not thrown scenario"
        /// </summary>
        [UnitTest]
        [ExceptionThrown(typeof(DivideByZeroException))]
        public void Divide_By_Zero_Exception_Is_Not_Thrown_Test()
        {
            int a = 0;
            int b = 4;

            a = a + b;
        }

    }
}
